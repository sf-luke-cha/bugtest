module.exports = function(app){
  app.get('/api/status', (req,res)=>{
    res.json({status: 'ok', time: Date.now()});
  });
}
